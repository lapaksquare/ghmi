<?php 

// multiple recipients
$to  = 'lapaksquare@gmail.com' . ', '; // note the comma
$to .= 'junaidyanton@hotmail.com' . ', ';
$to .= 'koding_in@yahoo.co.id';

// subject
$subject = 'TESTING EMAIL';

$message = '
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
<head style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
<!-- If you delete this meta tag, Half Life 3 will never be released. -->
<meta name="viewport" content="width=device-width" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
<title style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">GHM EDM TEST</title>






</head>
<body style="margin: 0;padding: 0;font-family: Arial;-webkit-font-smoothing: antialiased;-webkit-text-size-adjust: none;width: 100%;height: 100%;background: url(http://lapaksquare.com/gmhi/img/bg.jpg) repeat-x #2691d5;">

<div class="wrapper" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;background: url(http://lapaksquare.com/gmhi/img/pattern.png) repeat;">

<!-- HEADER -->
<table class="head-wrap" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;border-spacing: 0;width: 100%;">
	<tr style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
		<td style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;"></td>
		<td class="header container" style="margin: 0 auto;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;display: block;max-width: 600px;clear: both;">
			
				<div class="content bg_content" style="margin: 0 auto;padding: 0 8px 0 8px;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;max-width: 600px;display: block;background-color: rgba(255,255,255,.25);padding-top: 15px;">
					<table style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;border-spacing: 0;width: 100%;">
					<tr style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
						<td style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;"></td>
						<td style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;"><p class="email_info" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-weight: normal;font-size: 12px;line-height: 1.6;color: #fff;margin-bottom: 10px;">The best flight offers, last-minute deals and others promotions from Garuda Indonesia Airways .... <br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
Can’t view ? <a href="#" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #fff;text-decoration: none;font-weight: bold;">Click here</a> to view online</p></td>
					</tr>
				</table>
				</div>
				
		</td>
	</tr>
</table><!-- /HEADER -->

<!-- BODY -->
<table class="body-wrap" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;border-spacing: 0;width: 100%;">
	<tr style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
		<td class="container" style="margin: 0 auto;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;display: block;max-width: 600px;clear: both;">

			<div class="content bg_content" style="margin: 0 auto;padding: 0 8px 0 8px;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;max-width: 600px;display: block;background-color: rgba(255,255,255,.25);">
				<table style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;border-spacing: 0;width: 100%;">
					<tr style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
						<td style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
							<div class="email_banner" style="background-image: url(http://lapaksquare.com/gmhi/img/email_banner.jpg);margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;width: 100%;height: 281px;background-repeat: no-repeat;">
								<ul style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-weight: normal;font-size: 14px;line-height: 1.6;float: right;list-style: none;margin-top: 1px;">
									<li style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;margin-left: 5px;list-style-position: inside;display: inline-block;margin-right: 12px;"><a href="#" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #015fa8;text-decoration: none;font-size: 9px;line-height: 18px;">Earn Miles</a></li>
									<li style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;margin-left: 5px;list-style-position: inside;display: inline-block;margin-right: 12px;"><a href="#" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #015fa8;text-decoration: none;font-size: 9px;line-height: 18px;">Redeem Miles</a></li>
									<li style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;margin-left: 5px;list-style-position: inside;display: inline-block;margin-right: 12px;"><a href="#" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #015fa8;text-decoration: none;font-size: 9px;line-height: 18px;">About GFF</a></li>
									<li style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;margin-left: 5px;list-style-position: inside;display: inline-block;margin-right: 12px;"><a href="#" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #015fa8;text-decoration: none;font-size: 9px;line-height: 18px;">News & Offers</a></li>
									<li style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;margin-left: 5px;list-style-position: inside;display: inline-block;margin-right: 12px;"><a href="#" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #015fa8;text-decoration: none;font-size: 9px;line-height: 18px;">Book Flight</a></li>
								</ul>
							</div>
						</td>
					</tr>
				</table>
			</div>

		</td>
	</tr>
	<tr style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
		<td class="container" style="margin: 0 auto;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;display: block;max-width: 600px;clear: both;">

			<div class="content bg_content content_email" style="margin: 0 auto;padding: 0 8px 0 8px;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;max-width: 600px;display: block;background-color: rgba(255,255,255,.25);padding-bottom: 8px;">

				<div class="column-wrap body_email" style="margin: 0 auto;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;background-color: #fff;max-width: 600px;">
					<div class="column col_left" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;width: 400px;float: left;background: url(http://lapaksquare.com/gmhi/img/sidebar.png) no-repeat top right;min-height: 550px;">
						<table style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;border-spacing: 0;width: 100%;">
							<tr style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
								<td style="margin: 0;padding: 15px;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
									<p style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-weight: normal;font-size: 12px;line-height: 1.6;color: #6d6e71;">
	Dear <b style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">(GFF Members name)</b>,
	<br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;"><br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
	With Garuda Indonesia, your leisure or business travels become much more fun and rewarding. GFF Members can now earn twice as much mileage every time you fly with us to many favorite destinations!
	<br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;"><br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
	So what are you waiting for? <br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
	Seize this opportunity for the following routes: <br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;"><br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">

									</p>

									<table class="table_route" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;border-spacing: 0;width: 100%;">
										<tr style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
											<td colspan="5" bgcolor="#0b7bbf" style="margin: 0;padding: 15px;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;"></td>
										</tr>
										<tr style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
											<td class="cols cols_name cols_from_name" style="margin: 0;padding: 0 0 8px 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 15px;color: #0b7bbf;border-bottom: 3px solid #cdcdcd;">Medan</td>
											<td class="cols cols_route" style="margin: 0;padding: 0 7px;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 12px;color: #0b7bbf;border-bottom: 3px solid #cdcdcd;"><img src="http://lapaksquare.com/gmhi/img/flightroute.png" alt="route" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;max-width: 100%;"></td>
											<td class="cols cols_name cols_to_route" style="margin: 0;padding: 0 0 8px 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 15px;color: #0b7bbf;border-bottom: 3px solid #cdcdcd;padding-top: 17px;">Palembang <br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;"> <span style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;display: block;text-align: right;font-size: 10px;color: #6d6e71;margin-top: 4px;margin-right: 4px;">Economy & Executive</span></td>
											<td class="cols cols_to_route cals_routing" style="margin: 0;padding: 0 0 8px 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 12px;color: #0b7bbf;border-bottom: 3px solid #cdcdcd;padding-top: 17px;padding-right: 3px;"><img src="http://lapaksquare.com/gmhi/img/route.png" alt="route" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;max-width: 100%;"></td>
											<td class="cols" style="margin: 0;padding: 0 0 8px 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 12px;color: #0b7bbf;border-bottom: 3px solid #cdcdcd;">Until 30 June 2013</td>
										</tr>
										<tr style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
											<td class="cols cols_name cols_from_name" style="margin: 0;padding: 0 0 8px 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 15px;color: #0b7bbf;border-bottom: 3px solid #cdcdcd;">Jakarta</td>
											<td class="cols cols_route" style="margin: 0;padding: 0 7px;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 12px;color: #0b7bbf;border-bottom: 3px solid #cdcdcd;"><img src="http://lapaksquare.com/gmhi/img/flightroute.png" alt="route" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;max-width: 100%;"></td>
											<td class="cols cols_name cols_to_route" style="margin: 0;padding: 0 0 8px 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 15px;color: #0b7bbf;border-bottom: 3px solid #cdcdcd;padding-top: 17px;">Palembang <br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;"> <span style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;display: block;text-align: right;font-size: 10px;color: #6d6e71;margin-top: 4px;margin-right: 4px;">Executive</span></td>
											<td class="cols cols_to_route cals_routing" style="margin: 0;padding: 0 0 8px 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 12px;color: #0b7bbf;border-bottom: 3px solid #cdcdcd;padding-top: 17px;padding-right: 3px;"><img src="http://lapaksquare.com/gmhi/img/route.png" alt="route" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;max-width: 100%;"></td>
											<td class="cols" style="margin: 0;padding: 0 0 8px 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 12px;color: #0b7bbf;border-bottom: 3px solid #cdcdcd;">Until 30 June 2013</td>
										</tr>
										<tr style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
											<td class="cols cols_name" style="margin: 0;padding: 0 0 8px 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 15px;color: #0b7bbf;border-bottom: 3px solid #cdcdcd;">Jakarta</td>
											<td class="cols cols_route" style="margin: 0;padding: 0 7px;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 12px;color: #0b7bbf;border-bottom: 3px solid #cdcdcd;"><img src="http://lapaksquare.com/gmhi/img/flightroute.png" alt="route" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;max-width: 100%;"></td>
											<td class="cols cols_name cols_to_route" style="margin: 0;padding: 0 0 8px 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 15px;color: #0b7bbf;border-bottom: 3px solid #cdcdcd;padding-top: 17px;">Perth <br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;"> <span style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;display: block;text-align: right;font-size: 10px;color: #6d6e71;margin-top: 4px;margin-right: 4px;">Executive</span></td>
											<td class="cols cols_to_route cals_routing" style="margin: 0;padding: 0 0 8px 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 12px;color: #0b7bbf;border-bottom: 3px solid #cdcdcd;padding-top: 17px;padding-right: 3px;"><img src="http://lapaksquare.com/gmhi/img/route.png" alt="route" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;max-width: 100%;"></td>
											<td class="cols" style="margin: 0;padding: 0 0 8px 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 12px;color: #0b7bbf;border-bottom: 3px solid #cdcdcd;">Until 30 June 2013</td>
										</tr>
									</table>

									<br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
									<p style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-weight: normal;font-size: 12px;line-height: 1.6;color: #6d6e71;">
	Dont miss the opportunity! Book your flights soon through Garuda Indonesia Call Center at 0804 1807 807 or (021) 2351 9999, available 24 hours every day, or visit the nearest Garuda Indonesia Sales Office for reservation.
<br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;"><br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">

Warm regards,<br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;"><br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">

<b style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">Customer Loyalty</b>

<br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;"><br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">

<a href="#" class="btn" style="margin: 0;padding: 3px 0 0 11px;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #FFF;text-decoration: none;background-color: #666;font-weight: normal;margin-right: 10px;text-align: left;cursor: pointer;display: inline-block;background: url(http://lapaksquare.com/gmhi/img/button.png) no-repeat;width: 89px;height: 23px;font-size: 10px;text-transform: uppercase;letter-spacing: -1px;">Read More</a>
									</p>
								</td>
							</tr>
						</table>
					</div>
					<div class="column col_right" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;width: 180px;float: left;font-size: 12px;">
						<table style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;border-spacing: 0;width: 100%;">
							<tr style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
								<td style="margin: 0;padding: 15px;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
									<h3 style="margin: 0;padding: 0;font-family: &quot;HelveticaNeue-Light&quot;, &quot;Helvetica Neue Light&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, &quot;Lucida Grande&quot;, sans-serif;line-height: 1.1;color: #0460a9;font-weight: bold;font-size: 15px;text-transform: uppercase;letter-spacing: -1px;margin-bottom: 22px;">Your Account</h3>
									<p style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-weight: normal;font-size: 12px;line-height: 1.6;color: #6d6e71;">
										GFF No. <span class="txt_blue" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #0460a9;">123 456 789</span>
										<br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;"><br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
										Status as of DD/MMY/YYY<br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
										GFF Member Status 
										<span class="txt_blue" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #0460a9;">XXXXXX</span><br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
										Current Mileage :<br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
										<span class="txt_blue" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #0460a9;">XXXXXX Miles</span>

										<ul class="list_arrow" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-weight: normal;font-size: 14px;line-height: 1.6;margin-top: 14px;">
											<li style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;margin-left: 0;list-style-position: inside;list-style: none;display: block;"><a href="#" style="margin: 0;padding: 4px 0 0 8px;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: white;text-decoration: none;font-size: 9px;background: url(http://lapaksquare.com/gmhi/img/arrow.png) no-repeat;width: 112px;height: 21px;display: block;text-transform: uppercase;">Purchase Miles</a></li>
											<li style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;margin-left: 0;list-style-position: inside;list-style: none;display: block;"><a href="#" style="margin: 0;padding: 4px 0 0 8px;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: white;text-decoration: none;font-size: 9px;background: url(http://lapaksquare.com/gmhi/img/arrow.png) no-repeat;width: 112px;height: 21px;display: block;text-transform: uppercase;">Spend Miles</a></li>
											<li style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;margin-left: 0;list-style-position: inside;list-style: none;display: block;"><a href="#" style="margin: 0;padding: 4px 0 0 8px;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: white;text-decoration: none;font-size: 9px;background: url(http://lapaksquare.com/gmhi/img/arrow.png) no-repeat;width: 112px;height: 21px;display: block;text-transform: uppercase;">Claim Miles</a></li>
										</ul>

										<ul class="list_news" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-weight: normal;font-size: 14px;line-height: 1.6;margin-top: 12px;">
											<li style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;margin-left: 0;list-style-position: inside;list-style: none;display: block;margin-bottom: 10px;"><img src="http://lapaksquare.com/gmhi/img/news1.jpg" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;max-width: 100%;margin-bottom: 8px;display: block;"><a href="#" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #0b7bbf;text-decoration: none;font-size: 9px;">Enjoy Your Stay in Swiss-Belhotel, Indonesia</a></li>
											<li style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;margin-left: 0;list-style-position: inside;list-style: none;display: block;margin-bottom: 10px;"><img src="http://lapaksquare.com/gmhi/img/news2.jpg" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;max-width: 100%;margin-bottom: 8px;display: block;"><a href="#" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #0b7bbf;text-decoration: none;font-size: 9px;">Redeem GFF Mileage with Travel Package</a></li>
										</ul>

										<a href="#" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #2BA6CB;text-decoration: none;"><img src="http://lapaksquare.com/gmhi/img/logogaruda.png" alt="logogaruda" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;max-width: 100%;"></a>

									</p>
								</td>
							</tr>
						</table>
					</div>
					<div class="clear" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;display: block;clear: both;"></div>		

					<div class="content bg_content content_bottom" style="margin: 0 auto;padding: 0 8px 0 8px;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;max-width: 600px;display: block;background-color: rgba(255,255,255,.25);">
						<div class="hr hr_gray" style="margin: 8px 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;border-top: 2px solid #b8daf0;border-top-color: #cdcdcd;"></div>

						<p style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-weight: normal;font-size: 11px;line-height: 1.6;color: #605b5b;text-align: center;padding-bottom: 12px;">For more information please visit: <a href="#" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #2BA6CB;text-decoration: none;">https://gff.garuda-indonesia.com/</a></p>
					</div>

				</div>

			</div>

		</td>
	</tr>
</table>

<!-- FOOTER -->
<table class="footer-wrap" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;border-spacing: 0;padding-bottom: 12px;width: 100%;clear: both;">
	<tr style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
		<td style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;"></td>
		<td class="container" style="margin: 0 auto;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;display: block;max-width: 600px;clear: both;">
			
			<!-- content -->
			<div class="content content_nopadding" style="margin: 0 auto;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;max-width: 600px;display: block;">
				<table style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;border-spacing: 0;width: 100%;">
					<tr style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
						<td align="left" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
							<ul style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-weight: normal;font-size: 14px;line-height: 1.6;list-style: none;margin-top: 8px;">
								<li style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;margin-left: 0;list-style-position: inside;display: inline-block;margin-right: 12px;"><a href="#" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #fff;text-decoration: none;font-size: 11px;line-height: 18px;">My Account</a></li>
								<li style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;margin-left: 0;list-style-position: inside;display: inline-block;margin-right: 12px;"><a href="#" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #fff;text-decoration: none;font-size: 11px;line-height: 18px;">Earn Miles</a></li>
								<li style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;margin-left: 0;list-style-position: inside;display: inline-block;margin-right: 12px;"><a href="#" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #fff;text-decoration: none;font-size: 11px;line-height: 18px;">Redeem Miles</a></li>
								<li style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;margin-left: 0;list-style-position: inside;display: inline-block;margin-right: 12px;"><a href="#" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #fff;text-decoration: none;font-size: 11px;line-height: 18px;">About GFF</a></li>
								<li style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;margin-left: 0;list-style-position: inside;display: inline-block;margin-right: 12px;"><a href="#" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #fff;text-decoration: none;font-size: 11px;line-height: 18px;">News & Offers</a></li>
								<li style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;margin-left: 0;list-style-position: inside;display: inline-block;margin-right: 12px;"><a href="#" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: #fff;text-decoration: none;font-size: 11px;line-height: 18px;">Book Flight</a></li>
							</ul>
							<div class="clear" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;display: block;clear: both;"></div>	
							<div class="hr" style="margin: 8px 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;border-top: 2px solid #b8daf0;"></div>
							<p style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-weight: normal;font-size: 10px;line-height: 1.6;color: #fff;">Please do not reply to this email. The originating email account is automated and not monitored. To unsubscribe, <a href="#" style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;color: white;text-decoration: none;font-weight: bold;">click here</a> <br style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;">
							2013 Garuda indonesia Airways. All Right reserved. Review our privacy policy
							</p>
						</td>
					</tr>
				</table>
			</div><!-- /content -->
				
		</td>
		<td style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;"></td>
	</tr>
</table><!-- /FOOTER -->

</div>

</body>

</html>
';

// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// Additional headers
$headers .= 'From: ANTON <anton@tiket.com>' . "\r\n";

// Mail it
mail($to, $subject, $message, $headers);


?>